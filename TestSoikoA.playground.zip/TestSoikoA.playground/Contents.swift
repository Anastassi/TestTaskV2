import UIKit

enum Ingridients: Double {
    case orange = 2.3
    case mint = 4.5
    case spakrlingWater = 3.2
    case cranberry = 5.4
    case lime = 0.9
    case lemon = 1.9
    case raspberry = 8.3
    case coldWater = 7.5
    case nonAlchocolRedWine = 5.2
}
enum CoctailName {
    case orangeMojito
    case cranberrySparkler
    case pinkLemonade
    case sangriaPunch
}

var cocktails: [CoctailName: [Ingridients]] = [CoctailName.orangeMojito: [Ingridients.orange, Ingridients.mint, Ingridients.lime, Ingridients.spakrlingWater],
                                               CoctailName.cranberrySparkler: [Ingridients.cranberry, Ingridients.spakrlingWater, Ingridients.lime, Ingridients.orange],
                                               CoctailName.pinkLemonade: [Ingridients.lemon, Ingridients.orange, Ingridients.raspberry, Ingridients.mint, Ingridients.coldWater],
                                               CoctailName.sangriaPunch: [Ingridients.nonAlchocolRedWine, Ingridients.orange, Ingridients.lemon, Ingridients.lime, Ingridients.coldWater]]

var cocktailPrices: [CoctailName: Double] = [:]
for (cocktail, Ingridients) in cocktails {
    for (cocktail, Ingridients) in cocktails {
}
}
    averragePrice = averragePrice + value
}
}

